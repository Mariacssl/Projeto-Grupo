function validar(form){
    if(form.nome.value == ''){
        alert("O campo nome é obrigatório.");
        return false;
    }
    if(form.email.value == ''){
        alert("O campo e-mail é obrigatório.");
        return false;
    }
	if(form.email.value.indexOf(('@' && '.'),0)== -1){
    alert("E-mail inválido.");
    return false;
}
    if(form.mensagem.value == ''){
        alert("O campo detalhes e quantidade do pedido é obrigatótio.");
        return false;
    }
	if(form.mensagem.value.length < 10){
    alert("A mensagem está muito curta.");
    return false;
}

return true;
 
}  

